import argparse
import json
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split

from src.data_preprocessing import FEATURES, TARGET, REGIME, load_data, validate_data, make_demo_data
from src.regime_classifier import build_regime_classifier
from src.bias_correction import build_residual_model, uniform_correct, add_regime_feature
from src.evaluation import regression_metrics, classification_accuracy


def main():
    parser = argparse.ArgumentParser(description="Train regime-aware monsoon rainfall post-processing models.")
    parser.add_argument("--data", default="data/monsoon_data.csv", help="CSV path; absent default path triggers synthetic demo data.")
    parser.add_argument("--test-size", type=float, default=0.2)
    args = parser.parse_args()

    data_path = Path(args.data)
    generated_demo = not data_path.exists() and args.data == "data/monsoon_data.csv"
    if generated_demo:
        data_path.parent.mkdir(parents=True, exist_ok=True)
        demo = make_demo_data()
        demo.to_csv(data_path, index=False)
        print(f"Generated synthetic demonstration data: {data_path}")

    df = validate_data(load_data(args.data))
    X, y, regimes = df[FEATURES], df[TARGET], df[REGIME]

    X_train, X_test, y_train, y_test, r_train, r_test = train_test_split(
        X, y, regimes, test_size=args.test_size, random_state=42, stratify=regimes
    )

    classifier = build_regime_classifier()
    classifier.fit(X_train, r_train)
    train_regime_pred = classifier.predict(X_train)
    test_regime_pred = classifier.predict(X_test)

    train_residual = y_train.to_numpy() - X_train["rainfall_forecast"].to_numpy()
    test_raw = X_test["rainfall_forecast"].to_numpy()
    test_uniform = uniform_correct(test_raw, float(train_residual.mean()))

    residual_model = build_residual_model()
    residual_train_X = pd.get_dummies(add_regime_feature(X_train, train_regime_pred), columns=["predicted_regime"])
    residual_test_X = pd.get_dummies(add_regime_feature(X_test, test_regime_pred), columns=["predicted_regime"])
    residual_test_X = residual_test_X.reindex(columns=residual_train_X.columns, fill_value=0)
    residual_model.fit(residual_train_X, train_residual)
    test_regime_aware = (test_raw + residual_model.predict(residual_test_X)).clip(min=0)

    metrics = {
        "dataset_rows_after_cleaning": int(len(df)),
        "dataset_note": "Synthetic demonstration data; not suitable for scientific performance claims." if generated_demo else "User-supplied dataset; verify provenance and regime-label methodology.",
        "regime_classification_accuracy": classification_accuracy(r_test, test_regime_pred),
        "forecast_comparison": {
            "raw_forecast": regression_metrics(y_test, test_raw),
            "uniform_bias_correction": regression_metrics(y_test, test_uniform),
            "regime_aware_correction": regression_metrics(y_test, test_regime_aware),
        },
        "interpretation": "Lower MAE/RMSE is better. Evaluate on independent real forecast/observation data before making scientific claims.",
    }

    Path("models").mkdir(exist_ok=True)
    Path("reports").mkdir(exist_ok=True)
    joblib.dump({"classifier": classifier, "residual_model": residual_model,
                 "features": FEATURES, "uniform_residual": float(train_residual.mean())},
                "models/monsoon_models.joblib")

    with open("reports/metrics.json", "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2)

    names = ["Raw forecast", "Uniform correction", "Regime-aware"]
    maes = [metrics["forecast_comparison"][k]["MAE"] for k in
            ["raw_forecast", "uniform_bias_correction", "regime_aware_correction"]]
    rmses = [metrics["forecast_comparison"][k]["RMSE"] for k in
             ["raw_forecast", "uniform_bias_correction", "regime_aware_correction"]]

    for values, metric, filename in [(maes, "MAE (mm/day)", "mae_comparison.png"),
                                     (rmses, "RMSE (mm/day)", "rmse_comparison.png")]:
        plt.figure(figsize=(8, 5))
        plt.bar(names, values)
        plt.ylabel(metric)
        plt.title(f"Forecast comparison — {metric}")
        plt.xticks(rotation=12)
        plt.tight_layout()
        plt.savefig(Path("reports") / filename, dpi=160)
        plt.close()

    print(json.dumps(metrics, indent=2))
    print("\nSaved: models/monsoon_models.joblib, reports/metrics.json, reports/*.png")


if __name__ == "__main__":
    main()
