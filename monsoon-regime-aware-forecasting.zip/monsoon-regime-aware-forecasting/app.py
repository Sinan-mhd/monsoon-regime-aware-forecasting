import json
from pathlib import Path
import streamlit as st

st.set_page_config(page_title="Monsoon Forecast Post-Processing", layout="wide")
st.title("Regime-Aware Monsoon Rainfall Forecasting")
st.caption("G26 | SIH26080 | Prototype evaluation dashboard")

metrics_path = Path("reports/metrics.json")
if not metrics_path.exists():
    st.warning("No evaluation report found. Run `python train.py` first.")
    st.stop()

metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
st.info("Check the dataset provenance. Results from synthetic demo data are only a software demonstration.")
st.metric("Regime classification accuracy", f"{metrics['regime_classification_accuracy']:.3f}")
cols = st.columns(3)
labels = {
    "raw_forecast": "Raw forecast",
    "uniform_bias_correction": "Uniform correction",
    "regime_aware_correction": "Regime-aware correction",
}
for col, (key, label) in zip(cols, labels.items()):
    with col:
        st.subheader(label)
        st.metric("MAE", f"{metrics['forecast_comparison'][key]['MAE']:.2f} mm/day")
        st.metric("RMSE", f"{metrics['forecast_comparison'][key]['RMSE']:.2f} mm/day")

st.subheader("Metric comparison")
st.bar_chart({
    label: {
        "MAE": metrics["forecast_comparison"][key]["MAE"],
        "RMSE": metrics["forecast_comparison"][key]["RMSE"],
    }
    for key, label in labels.items()
})
st.caption(metrics["interpretation"])
