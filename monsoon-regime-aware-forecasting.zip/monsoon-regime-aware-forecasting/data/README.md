# Data directory

The repository does not include real meteorological observations or forecasts.

Run `python train.py` to generate a synthetic demonstration CSV locally. For real experiments, place your prepared CSV here as `monsoon_data.csv` and follow the schema in the root README. Check data licensing and attribution before committing any dataset.
