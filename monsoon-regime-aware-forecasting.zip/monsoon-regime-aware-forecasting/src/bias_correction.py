import numpy as np
from sklearn.ensemble import RandomForestRegressor


def build_residual_model(random_state: int = 42):
    return RandomForestRegressor(
        n_estimators=300,
        max_depth=14,
        min_samples_leaf=4,
        random_state=random_state,
        n_jobs=-1,
    )


def uniform_correct(forecast, mean_training_residual: float):
    return np.maximum(0, np.asarray(forecast) + mean_training_residual)


def add_regime_feature(X, predicted_regimes):
    result = X.copy()
    result["predicted_regime"] = np.asarray(predicted_regimes).astype(str)
    return result
