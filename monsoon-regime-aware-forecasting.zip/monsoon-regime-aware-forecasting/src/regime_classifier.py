from sklearn.ensemble import RandomForestClassifier


def build_regime_classifier(random_state: int = 42):
    return RandomForestClassifier(
        n_estimators=250,
        max_depth=12,
        min_samples_leaf=3,
        class_weight="balanced",
        random_state=random_state,
        n_jobs=-1,
    )
