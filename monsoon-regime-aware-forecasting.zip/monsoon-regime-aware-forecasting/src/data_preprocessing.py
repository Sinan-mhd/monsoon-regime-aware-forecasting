from pathlib import Path
import numpy as np
import pandas as pd

FEATURES = [
    "rainfall_forecast",
    "temperature_anomaly",
    "humidity",
    "wind_speed",
    "pressure_anomaly",
    "rainfall_lag_1d",
    "rainfall_lag_3d",
]
TARGET = "observed_rainfall"
REGIME = "regime"


def make_demo_data(n_samples: int = 2400, random_state: int = 42) -> pd.DataFrame:
    """Create clearly synthetic data for a reproducible end-to-end smoke test."""
    rng = np.random.default_rng(random_state)
    regimes = rng.choice(["Active", "Break", "Other"], size=n_samples, p=[0.35, 0.30, 0.35])

    temp = rng.normal(0, 1.2, n_samples)
    humidity = np.where(regimes == "Active", rng.normal(82, 6, n_samples),
               np.where(regimes == "Break", rng.normal(66, 7, n_samples), rng.normal(74, 8, n_samples)))
    wind = np.where(regimes == "Active", rng.normal(8.5, 1.8, n_samples),
           np.where(regimes == "Break", rng.normal(4.0, 1.2, n_samples), rng.normal(6.0, 1.8, n_samples)))
    pressure = np.where(regimes == "Active", rng.normal(-1.2, 0.7, n_samples),
               np.where(regimes == "Break", rng.normal(1.0, 0.7, n_samples), rng.normal(0, 0.8, n_samples)))
    lag1 = np.where(regimes == "Active", rng.gamma(3.0, 12.0, n_samples),
           np.where(regimes == "Break", rng.gamma(1.2, 5.0, n_samples), rng.gamma(1.8, 8.0, n_samples)))
    lag3 = np.maximum(0, lag1 * rng.normal(1.0, 0.35, n_samples) + rng.normal(0, 8, n_samples))

    base = np.where(regimes == "Active", 42, np.where(regimes == "Break", 8, 20))
    observed = np.maximum(0, base + 0.30 * lag1 + 0.12 * (humidity - 70) + 1.2 * wind
                          - 2.0 * pressure + rng.normal(0, 12, n_samples))
    # Deliberately regime-dependent forecast bias for demonstrating the method.
    bias = np.where(regimes == "Active", -10, np.where(regimes == "Break", 8, -2))
    forecast = np.maximum(0, observed + bias + rng.normal(0, 15, n_samples))

    return pd.DataFrame({
        "rainfall_forecast": forecast,
        "temperature_anomaly": temp,
        "humidity": humidity,
        "wind_speed": wind,
        "pressure_anomaly": pressure,
        "rainfall_lag_1d": lag1,
        "rainfall_lag_3d": lag3,
        "observed_rainfall": observed,
        "regime": regimes,
    })


def load_data(path: str | None = None) -> pd.DataFrame:
    if path is None:
        path = "data/monsoon_data.csv"
    file_path = Path(path)
    if not file_path.exists():
        if str(path) == "data/monsoon_data.csv":
            return make_demo_data()
        raise FileNotFoundError(f"Dataset not found: {file_path}")
    return pd.read_csv(file_path)


def validate_data(df: pd.DataFrame) -> pd.DataFrame:
    required = FEATURES + [TARGET, REGIME]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    clean = df[required].copy()
    for col in FEATURES + [TARGET]:
        clean[col] = pd.to_numeric(clean[col], errors="coerce")
    clean[REGIME] = clean[REGIME].astype("string")
    clean = clean.replace([np.inf, -np.inf], np.nan).dropna()
    clean = clean[clean[TARGET] >= 0]
    if clean[REGIME].nunique() < 2:
        raise ValueError("At least two regime classes are required.")
    if len(clean) < 50:
        raise ValueError("At least 50 valid rows are required.")
    return clean.reset_index(drop=True)
