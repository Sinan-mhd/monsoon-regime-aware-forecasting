import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error, accuracy_score


def regression_metrics(y_true, y_pred):
    return {
        "MAE": float(mean_absolute_error(y_true, y_pred)),
        "RMSE": float(np.sqrt(mean_squared_error(y_true, y_pred))),
    }


def classification_accuracy(y_true, y_pred):
    return float(accuracy_score(y_true, y_pred))
