# Regime-Aware Post-Processing of Monsoon Rainfall Forecasts

**SIH Problem ID:** SIH26080  
**Project group:** G26  
**Organisation:** Ministry of Earth Sciences (MoES)

A prototype pipeline that:
1. classifies a monsoon regime from meteorological features;
2. corrects raw rainfall forecasts using a uniform bias baseline;
3. applies a regime-aware residual correction;
4. evaluates raw, uniform-correction and regime-aware forecasts using MAE and RMSE.

> **Important:** The included dataset is synthetic demonstration data. It is intended to verify that the code runs end-to-end, not to claim real-world forecast skill. Replace it with quality-controlled historical forecast/observation data and defensible regime labels before reporting scientific results.

## Quick start

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
python train.py
```

This generates `data/demo_monsoon.csv`, trains the models, writes metrics to `reports/metrics.json`, saves plots in `reports/`, and serializes models in `models/`.

Optional dashboard:

```bash
streamlit run app.py
```

## Real-data CSV schema

Supply a CSV at `data/monsoon_data.csv` with these columns:

| Column | Meaning |
|---|---|
| `rainfall_forecast` | Raw forecast rainfall (mm/day) |
| `temperature_anomaly` | Temperature anomaly (°C) |
| `humidity` | Relative humidity (%) |
| `wind_speed` | Wind speed (m/s) |
| `pressure_anomaly` | Pressure anomaly (hPa) |
| `rainfall_lag_1d` | Previous-day observed rainfall (mm/day) |
| `rainfall_lag_3d` | Three-day lagged observed rainfall (mm/day) |
| `observed_rainfall` | Observed rainfall (mm/day), target |
| `regime` | Regime label, e.g. Active / Break / Other |

Then run:

```bash
python train.py --data data/monsoon_data.csv
```

The `regime` labels must be derived from a documented, domain-appropriate method and aligned to the forecast date/location. Do not infer or invent labels from the target column without documenting the method. Ensure all predictors are available at forecast issuance time to avoid data leakage.

## Project structure

```text
data/                 # demo data; real datasets are not committed
models/               # trained model artifacts
notebooks/            # space for exploratory work
reports/              # evaluation metrics and plots
src/
  data_preprocessing.py
  regime_classifier.py
  bias_correction.py
  evaluation.py
train.py
app.py
requirements.txt
```

## Method

- **Regime classifier:** Random Forest classifier trained on meteorological predictors.
- **Uniform baseline:** adds the mean training residual (`observed - forecast`) to every test forecast.
- **Regime-aware model:** Random Forest regressor predicts the residual using meteorological predictors plus the classifier-predicted regime.
- **Evaluation:** chronological holdout split when dates are provided; otherwise a stratified random split. MAE and RMSE are reported for each method, alongside regime classification accuracy.

The demo data uses a random split because it has no real dates. For real forecasting, prefer a chronological split and, where possible, spatial/temporal independent validation.

## Limitations and next steps

- The demo generator creates illustrative patterns; it is not a physical monsoon simulator.
- Real active/break regime definitions should follow an accepted meteorological reference and the project's study region.
- Use forecast-vintage data rather than reanalysis/observations that would not have been available at forecast time.
- Consider spatial validation, seasonal validation, uncertainty estimates, and comparison with a simple climatology baseline.
